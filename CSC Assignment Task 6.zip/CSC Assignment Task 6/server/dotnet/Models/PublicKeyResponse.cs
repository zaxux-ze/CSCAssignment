﻿public class PublicKeyResponse
{
    public string PublicKey { get; set; }
}