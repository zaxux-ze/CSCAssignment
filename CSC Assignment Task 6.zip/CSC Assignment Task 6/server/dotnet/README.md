## Run with

```sh
dotnet run Program.cs
```
